const steps = [
  "https://i.imgur.com/Z1J05bL.png",  // Step 1
  "https://i.imgur.com/yVzsmEl.png",  // Step 2
  "https://i.imgur.com/FxxWNjn.png"   // Step 3
];

let currentStep = 0;

const image = document.getElementById("interactive-image");

image.addEventListener("click", function() {
  currentStep++;
  if (currentStep >= steps.length) {
    currentStep = 0;
  }
  image.src = steps[currentStep];
});